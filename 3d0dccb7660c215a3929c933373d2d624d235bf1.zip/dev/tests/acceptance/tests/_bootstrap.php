<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

//TODO remove this file once MFTF is fully decoupled from Magento
// Need to load in the root level autload file
require_once realpath(dirname(__DIR__) . "/../../../vendor/autoload.php");
